# Boda Moja Mobile Apps

React Native mobile applications for the Boda Moja ride-hailing platform.

## Project Structure

```
boda-moja-mobile/
├── rider-app/          # Rider mobile app
│   ├── src/
│   │   ├── screens/     # All screen components
│   │   ├── services/    # API, Socket, Location
│   │   ├── stores/      # Zustand state management
│   │   └── components/  # Reusable components
│   ├── assets/          # Images and fonts
│   └── App.js           # Entry point
│
└── driver-app/         # Driver mobile app
    ├── src/
    │   ├── screens/     # All screen components
    │   ├── services/    # API, Socket, Location
    │   ├── stores/      # Zustand state management
    │   └── components/  # Reusable components
    ├── assets/          # Images and fonts
    └── App.js           # Entry point
```

## Rider App Features

- **Authentication**: Phone-based login/register
- **Map Integration**: Google Maps with Places Autocomplete
- **Ride Booking**: Select pickup/dropoff, see fare estimate
- **Real-time Tracking**: Watch driver approach on map
- **M-Pesa Payments**: Automatic STK push on ride completion
- **Ride History**: View past rides and payments
- **Ratings**: Rate drivers after each ride

## Driver App Features

- **Authentication**: Phone-based login/register with verification
- **Online/Offline Toggle**: Control availability
- **GPS Tracking**: Background location updates every 3 seconds
- **Ride Requests**: Accept/decline with 30-second countdown
- **Navigation**: Turn-by-turn to pickup and destination
- **Earnings Tracking**: Daily/weekly/monthly summaries
- **Profile**: Verification status and statistics

## Getting Started

### Prerequisites
- Node.js 18+
- Expo CLI: `npm install -g expo-cli`
- Expo Go app on your phone (for testing)

### Setup

1. **Install dependencies**
```bash
cd rider-app
npm install

cd ../driver-app
npm install
```

2. **Configure environment variables**
```bash
# In both apps, edit .env
API_BASE_URL=https://api.bodamoja.com/v1
SOCKET_URL=https://api.bodamoja.com
GOOGLE_PLACES_API_KEY=your_key_here
GOOGLE_MAPS_API_KEY=your_key_here
```

3. **Add app images**
Add your logo and icon images to `assets/images/` in both apps.

4. **Start development**
```bash
# Rider app
cd rider-app
expo start

# Driver app (new terminal)
cd driver-app
expo start
```

5. **Test on device**
- Open Expo Go on your phone
- Scan the QR code from the terminal

## Building for Production

### EAS Build (Recommended)

```bash
# Install EAS CLI
npm install -g eas-cli

# Login to Expo
eas login

# Configure build
eas build:configure

# Build for Android
eas build --platform android --profile production

# Build for iOS (requires Apple Developer account)
eas build --platform ios --profile production
```

### Environment-Specific Builds

```bash
# Development (with dev tools)
eas build --profile development

# Preview (internal testing)
eas build --profile preview

# Production (app store)
eas build --profile production
```

## Architecture

### State Management
- **Zustand** for global state (auth, user data)
- **React state** for local UI state

### Navigation
- **React Navigation v6**
- Stack Navigator for auth flow
- Bottom Tabs for main app
- Modal presentation for ride requests

### Real-time Communication
- **Socket.io** for live updates
- Automatic reconnection with exponential backoff
- JWT authentication in handshake

### Location Services
- **Expo Location** for GPS
- Foreground tracking for riders
- Background tracking for drivers (when online)
- 3-second update interval

### Security
- **Expo SecureStore** for JWT tokens (never AsyncStorage)
- API interceptors for automatic token attachment
- HTTPS-only communication

## Screens

### Rider App
| Screen | Description |
|--------|-------------|
| SplashScreen | Animated app logo |
| LoginScreen | Phone + password login |
| RegisterScreen | New rider registration |
| HomeScreen | Map with pickup/dropoff selection |
| ConfirmRideScreen | Fare estimate and booking |
| WaitingScreen | Finding drivers animation |
| RideScreen | Active ride with driver tracking |
| PaymentScreen | M-Pesa payment status |
| RatingScreen | Rate completed ride |
| RideHistoryScreen | Past rides list |
| ProfileScreen | User settings and logout |

### Driver App
| Screen | Description |
|--------|-------------|
| SplashScreen | Animated app logo |
| LoginScreen | Phone + password login |
| RegisterScreen | New driver registration |
| HomeScreen | Map with online/offline toggle |
| RequestPopupScreen | Incoming ride request modal |
| NavigationScreen | Active ride navigation |
| EarningsScreen | Income statistics |
| ProfileScreen | Driver info and verification |

## Customization

### Colors
Primary brand color is `#FF6B00` (orange). Update in:
- Screen StyleSheet objects
- app.json splash background
- app.json adaptive icon background

### Fonts
Add custom fonts to `assets/fonts/` and load in App.js:
```javascript
import { useFonts } from 'expo-font';

const [fontsLoaded] = useFonts({
  'CustomFont': require('./assets/fonts/CustomFont.ttf'),
});
```

## Troubleshooting

### Maps not showing
- Verify Google Maps API key has Maps SDK enabled
- Check API key restrictions (add your app bundle ID)
- For iOS: Add API key to app.json config

### Location not working
- Grant location permissions in device settings
- For background: Enable "Always" permission
- Android: Check manifest permissions

### Socket not connecting
- Verify SOCKET_URL matches your API domain
- Check JWT token is valid (not expired)
- Ensure API server is running and accessible

## License

MIT
