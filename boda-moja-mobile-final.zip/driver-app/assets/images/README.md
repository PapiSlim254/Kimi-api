# Placeholder Images

Add your app images to this directory:

Required images:
- icon.png (1024x1024) - App icon
- adaptive-icon.png (1024x1024) - Android adaptive icon foreground
- splash.png (1242x2436) - Splash screen
- favicon.png (48x48) - Web favicon
- logo.png - App logo for splash
- logo-placeholder.png - Fallback logo

You can generate these using:
- Figma
- Canva
- Or use the Expo default assets
