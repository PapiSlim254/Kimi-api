import { create } from 'zustand';
import * as SecureStore from 'expo-secure-store';
import api from './api';

const useAuthStore = create((set, get) => ({
  // State
  user: null,
  token: null,
  isLoading: false,
  isAuthenticated: false,
  role: null, // 'rider' or 'driver'

  // Actions
  setUser: (user) => set({ user, isAuthenticated: !!user }),

  login: async (phone, password, role) => {
    set({ isLoading: true });
    try {
      const endpoint = role === 'rider' ? '/auth/rider/login' : '/auth/driver/login';
      const response = await api.post(endpoint, { phone, password });
      const { token, [role]: userData } = response.data.data;

      await SecureStore.setItemAsync('auth_token', token);

      set({ 
        user: userData, 
        token, 
        isAuthenticated: true, 
        isLoading: false,
        role,
      });

      return { success: true };
    } catch (error) {
      set({ isLoading: false });
      return { 
        success: false, 
        error: error.response?.data?.error?.message || 'Login failed' 
      };
    }
  },

  register: async (data, role) => {
    set({ isLoading: true });
    try {
      const endpoint = role === 'rider' ? '/auth/rider/register' : '/auth/driver/register';
      const response = await api.post(endpoint, data);
      const { token, [role]: userData } = response.data.data;

      await SecureStore.setItemAsync('auth_token', token);

      set({ 
        user: userData, 
        token, 
        isAuthenticated: true, 
        isLoading: false,
        role,
      });

      return { success: true };
    } catch (error) {
      set({ isLoading: false });
      return { 
        success: false, 
        error: error.response?.data?.error?.message || 'Registration failed' 
      };
    }
  },

  logout: async () => {
    await SecureStore.deleteItemAsync('auth_token');
    set({ user: null, token: null, isAuthenticated: false, role: null });
  },

  checkAuth: async () => {
    try {
      const token = await SecureStore.getItemAsync('auth_token');
      if (!token) {
        set({ isAuthenticated: false });
        return;
      }

      const response = await api.get('/auth/me');
      const userData = response.data.data;

      set({ 
        user: userData, 
        token, 
        isAuthenticated: true,
        role: userData.role,
      });
    } catch {
      await SecureStore.deleteItemAsync('auth_token');
      set({ user: null, token: null, isAuthenticated: false, role: null });
    }
  },
}));

export default useAuthStore;
