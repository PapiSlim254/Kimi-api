import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Switch,
} from 'react-native';
import api from '../services/api';
import useAuthStore from '../stores/authStore';

export default function ProfileScreen() {
  const { user, logout } = useAuthStore();
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const response = await api.get('/drivers/me/profile');
      setProfile(response.data.data.driver);
    } catch (error) {
      console.error('Failed to fetch profile:', error);
    }
  };

  const handleLogout = async () => {
    await logout();
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>{profile?.name?.[0] || '?'}</Text>
        </View>
        <Text style={styles.name}>{profile?.name || 'Driver'}</Text>
        <Text style={styles.phone}>{profile?.phone || ''}</Text>

        <View style={styles.ratingBadge}>
          <Text style={styles.ratingText}>⭐ {profile?.ratingAvg || '5.0'}</Text>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Verification Status</Text>

        <View style={styles.verificationItem}>
          <Text style={styles.verificationLabel}>Account Verified</Text>
          <View style={[styles.statusBadge, profile?.isVerified ? styles.verified : styles.pending]}>
            <Text style={styles.statusText}>
              {profile?.isVerified ? '✅ Verified' : '⏳ Pending'}
            </Text>
          </View>
        </View>

        <View style={styles.verificationItem}>
          <Text style={styles.verificationLabel}>License Number</Text>
          <Text style={styles.verificationValue}>{profile?.licenseNumber || 'N/A'}</Text>
        </View>

        <View style={styles.verificationItem}>
          <Text style={styles.verificationLabel}>ID Number</Text>
          <Text style={styles.verificationValue}>{profile?.idNumber || 'N/A'}</Text>
        </View>

        {profile?.sacco && (
          <View style={styles.verificationItem}>
            <Text style={styles.verificationLabel}>SACCO</Text>
            <Text style={styles.verificationValue}>{profile.sacco.name}</Text>
          </View>
        )}
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Statistics</Text>

        <View style={styles.statRow}>
          <Text style={styles.statLabel}>Total Rides</Text>
          <Text style={styles.statValue}>{profile?._count?.rides || 0}</Text>
        </View>
      </View>

      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
        <Text style={styles.logoutText}>Logout</Text>
      </TouchableOpacity>

      <Text style={styles.version}>Boda Moja Driver v1.0.0</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#FF6B00',
    padding: 32,
    alignItems: 'center',
  },
  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  avatarText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#FF6B00',
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 4,
  },
  phone: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
    marginBottom: 12,
  },
  ratingBadge: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  ratingText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  section: {
    backgroundColor: 'white',
    marginTop: 16,
    paddingVertical: 8,
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#999',
    textTransform: 'uppercase',
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  verificationItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  verificationLabel: {
    fontSize: 16,
    color: '#333',
  },
  verificationValue: {
    fontSize: 14,
    color: '#666',
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  verified: {
    backgroundColor: '#E8F5E9',
  },
  pending: {
    backgroundColor: '#FFF3E0',
  },
  statusText: {
    fontSize: 12,
    fontWeight: 'bold',
  },
  statRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  statLabel: {
    fontSize: 16,
    color: '#333',
  },
  statValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FF6B00',
  },
  logoutButton: {
    backgroundColor: 'white',
    marginTop: 16,
    padding: 16,
    alignItems: 'center',
  },
  logoutText: {
    color: '#ff4444',
    fontSize: 16,
    fontWeight: 'bold',
  },
  version: {
    textAlign: 'center',
    color: '#999',
    fontSize: 12,
    marginVertical: 24,
  },
});
