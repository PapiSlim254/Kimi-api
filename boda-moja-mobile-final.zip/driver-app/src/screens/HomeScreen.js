import React, { useEffect, useState, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Switch,
  ActivityIndicator,
} from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import * as TaskManager from 'expo-task-manager';
import * as BackgroundFetch from 'expo-background-fetch';
import { requestLocationPermission, getCurrentLocation, watchLocation } from '../services/location';
import { emitEvent, onEvent, offEvent, getSocket } from '../services/socket';
import api from '../services/api';
import useAuthStore from '../stores/authStore';
import Toast from 'react-native-toast-message';

const { width, height } = Dimensions.get('window');
const LOCATION_TASK_NAME = 'background-location-task';

// Background location task
TaskManager.defineTask(LOCATION_TASK_NAME, async ({ data, error }) => {
  if (error) {
    console.error('Background location error:', error);
    return;
  }
  if (data) {
    const { locations } = data;
    const socket = getSocket();
    if (socket?.connected) {
      socket.emit('location_update', {
        lat: locations[0].coords.latitude,
        lng: locations[0].coords.longitude,
      });
    }
  }
});

export default function HomeScreen({ navigation }) {
  const { user } = useAuthStore();
  const [isOnline, setIsOnline] = useState(false);
  const [region, setRegion] = useState(null);
  const [currentRide, setCurrentRide] = useState(null);
  const [rideRequest, setRideRequest] = useState(null);
  const locationSubscription = useRef(null);

  useEffect(() => {
    initializeLocation();

    // Listen for ride requests
    onEvent('ride_requested', handleRideRequest);
    onEvent('ride_cancelled', handleRideCancelled);

    return () => {
      offEvent('ride_requested', handleRideRequest);
      offEvent('ride_cancelled', handleRideCancelled);
      if (locationSubscription.current) {
        locationSubscription.current.remove();
      }
    };
  }, []);

  const initializeLocation = async () => {
    try {
      await requestLocationPermission();
      const location = await getCurrentLocation();

      setRegion({
        latitude: location.lat,
        longitude: location.lng,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    } catch (error) {
      Toast.show({ type: 'error', text1: 'Location access required' });
    }
  };

  const handleRideRequest = useCallback((data) => {
    if (!isOnline) return; // Ignore if offline

    setRideRequest(data);
    navigation.navigate('RequestPopup', { 
      request: data,
      onAccept: () => acceptRide(data.rideId),
      onDecline: () => declineRide(),
    });
  }, [isOnline, navigation]);

  const handleRideCancelled = useCallback((data) => {
    if (rideRequest && rideRequest.rideId === data.rideId) {
      setRideRequest(null);
      Toast.show({ type: 'info', text1: 'Ride request cancelled by rider' });
    }
  }, [rideRequest]);

  const toggleOnline = async () => {
    if (!user?.isVerified) {
      Toast.show({ type: 'error', text1: 'Account pending verification' });
      return;
    }

    const newStatus = !isOnline;

    try {
      await api.patch('/drivers/me/status', { isOnline: newStatus });
      setIsOnline(newStatus);

      if (newStatus) {
        // Start location tracking
        emitEvent('go_online', {});
        startLocationTracking();
        Toast.show({ type: 'success', text1: 'You are now online' });
      } else {
        // Stop location tracking
        emitEvent('go_offline', {});
        stopLocationTracking();
        Toast.show({ type: 'info', text1: 'You are now offline' });
      }
    } catch (error) {
      Toast.show({ type: 'error', text1: 'Failed to update status' });
    }
  };

  const startLocationTracking = async () => {
    try {
      // Foreground tracking
      locationSubscription.current = await watchLocation((location) => {
        emitEvent('location_update', location);
      });

      // Background tracking
      await BackgroundFetch.registerTaskAsync(LOCATION_TASK_NAME, {
        minimumInterval: 3,
        stopOnTerminate: false,
        startOnBoot: true,
      });
    } catch (error) {
      console.error('Location tracking error:', error);
    }
  };

  const stopLocationTracking = async () => {
    if (locationSubscription.current) {
      locationSubscription.current.remove();
      locationSubscription.current = null;
    }

    try {
      await BackgroundFetch.unregisterTaskAsync(LOCATION_TASK_NAME);
    } catch (error) {
      console.error('Failed to unregister background task:', error);
    }
  };

  const acceptRide = async (rideId) => {
    try {
      await api.patch(`/rides/${rideId}/accept`);
      setRideRequest(null);
      setCurrentRide(rideId);
      Toast.show({ type: 'success', text1: 'Ride accepted!' });
      navigation.navigate('Navigation', { rideId });
    } catch (error) {
      Toast.show({ type: 'error', text1: 'Failed to accept ride' });
    }
  };

  const declineRide = () => {
    setRideRequest(null);
  };

  if (!region) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#FF6B00" />
        <Text style={styles.loadingText}>Getting location...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <MapView
        style={styles.map}
        region={region}
        showsUserLocation
        showsMyLocationButton
      />

      <View style={styles.overlay}>
        <View style={styles.statusCard}>
          <Text style={styles.statusText}>
            {isOnline ? 'Online - Accepting Rides' : 'Offline'}
          </Text>
          <Switch
            trackColor={{ false: '#767577', true: '#4CAF50' }}
            thumbColor={isOnline ? '#fff' : '#f4f3f4'}
            ios_backgroundColor="#3e3e3e"
            onValueChange={toggleOnline}
            value={isOnline}
          />
        </View>

        {!user?.isVerified && (
          <View style={styles.verificationBanner}>
            <Text style={styles.verificationText}>
              ⚠️ Account pending verification. You cannot go online yet.
            </Text>
          </View>
        )}

        {isOnline && !currentRide && (
          <View style={styles.waitingCard}>
            <ActivityIndicator size="small" color="#FF6B00" />
            <Text style={styles.waitingText}>Waiting for ride requests...</Text>
          </View>
        )}

        {currentRide && (
          <TouchableOpacity 
            style={styles.activeRideButton}
            onPress={() => navigation.navigate('Navigation', { rideId: currentRide })}
          >
            <Text style={styles.activeRideText}>Active Ride</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FF6B00',
  },
  loadingText: {
    marginTop: 16,
    color: 'white',
    fontSize: 16,
  },
  overlay: {
    position: 'absolute',
    top: 50,
    left: 16,
    right: 16,
  },
  statusCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statusText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  verificationBanner: {
    backgroundColor: '#FFF3CD',
    borderRadius: 12,
    padding: 12,
    marginTop: 12,
  },
  verificationText: {
    color: '#856404',
    fontSize: 14,
  },
  waitingCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 16,
    marginTop: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  waitingText: {
    marginLeft: 8,
    fontSize: 14,
    color: '#666',
  },
  activeRideButton: {
    backgroundColor: '#FF6B00',
    borderRadius: 16,
    padding: 16,
    marginTop: 12,
    alignItems: 'center',
  },
  activeRideText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
