import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import MapViewDirections from 'react-native-maps-directions';
import { onEvent, offEvent, emitEvent } from '../services/socket';
import api from '../services/api';
import Toast from 'react-native-toast-message';

const { width, height } = Dimensions.get('window');

export default function NavigationScreen({ route, navigation }) {
  const { rideId } = route.params;
  const [ride, setRide] = useState(null);
  const [driverLocation, setDriverLocation] = useState(null);
  const [status, setStatus] = useState('accepted');
  const mapRef = useRef(null);

  useEffect(() => {
    fetchRideDetails();

    onEvent('driver_location', handleLocationUpdate);

    return () => {
      offEvent('driver_location', handleLocationUpdate);
    };
  }, []);

  const fetchRideDetails = async () => {
    try {
      const response = await api.get(`/rides/${rideId}`);
      setRide(response.data.data.ride);
      setStatus(response.data.data.ride.status);
    } catch (error) {
      console.error('Failed to fetch ride:', error);
    }
  };

  const handleLocationUpdate = (data) => {
    setDriverLocation({ lat: data.lat, lng: data.lng });
  };

  const handleArriving = async () => {
    try {
      await api.patch(`/rides/${rideId}/arriving`);
      setStatus('driver_arriving');
      Toast.show({ type: 'success', text1: 'Marked as arriving' });
    } catch (error) {
      Toast.show({ type: 'error', text1: 'Failed to update status' });
    }
  };

  const handleStartRide = async () => {
    try {
      await api.patch(`/rides/${rideId}/start`);
      setStatus('in_progress');
      Toast.show({ type: 'success', text1: 'Ride started!' });
    } catch (error) {
      Toast.show({ type: 'error', text1: 'Failed to start ride' });
    }
  };

  const handleCompleteRide = async () => {
    try {
      await api.patch(`/rides/${rideId}/complete`);
      Toast.show({ type: 'success', text1: 'Ride completed!' });
      navigation.navigate('Main');
    } catch (error) {
      Toast.show({ type: 'error', text1: 'Failed to complete ride' });
    }
  };

  const getActionButton = () => {
    switch (status) {
      case 'accepted':
        return (
          <TouchableOpacity style={styles.actionButton} onPress={handleArriving}>
            <Text style={styles.actionText}>I've Arrived</Text>
          </TouchableOpacity>
        );
      case 'driver_arriving':
        return (
          <TouchableOpacity style={styles.actionButton} onPress={handleStartRide}>
            <Text style={styles.actionText}>Start Ride</Text>
          </TouchableOpacity>
        );
      case 'in_progress':
        return (
          <TouchableOpacity style={[styles.actionButton, styles.completeButton]} onPress={handleCompleteRide}>
            <Text style={styles.actionText}>Complete Ride</Text>
          </TouchableOpacity>
        );
      default:
        return null;
    }
  };

  const getStatusText = () => {
    switch (status) {
      case 'accepted': return 'Heading to pickup';
      case 'driver_arriving': return 'Waiting for rider';
      case 'in_progress': return 'Heading to destination';
      default: return '';
    }
  };

  if (!ride) {
    return (
      <View style={styles.loadingContainer}>
        <Text>Loading ride details...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <MapView
        ref={mapRef}
        style={styles.map}
        showsUserLocation
      >
        <Marker coordinate={{ latitude: parseFloat(ride.pickupLat), longitude: parseFloat(ride.pickupLng) }}>
          <View style={styles.markerPickup}>
            <Text style={styles.markerText}>P</Text>
          </View>
        </Marker>

        <Marker coordinate={{ latitude: parseFloat(ride.dropoffLat), longitude: parseFloat(ride.dropoffLng) }}>
          <View style={styles.markerDropoff}>
            <Text style={styles.markerText}>D</Text>
          </View>
        </Marker>

        {driverLocation && (
          <Marker coordinate={{ latitude: driverLocation.lat, longitude: driverLocation.lng }}>
            <View style={styles.driverMarker}>
              <Text>🏍</Text>
            </View>
          </Marker>
        )}

        <MapViewDirections
          origin={{ latitude: parseFloat(ride.pickupLat), longitude: parseFloat(ride.pickupLng) }}
          destination={{ latitude: parseFloat(ride.dropoffLat), longitude: parseFloat(ride.dropoffLng) }}
          apikey={process.env.GOOGLE_MAPS_API_KEY}
          strokeWidth={4}
          strokeColor="#FF6B00"
        />
      </MapView>

      <View style={styles.card}>
        <Text style={styles.status}>{getStatusText()}</Text>

        <View style={styles.rideInfo}>
          <Text style={styles.infoText}>Pickup: {ride.pickupAddress}</Text>
          <Text style={styles.infoText}>Dropoff: {ride.dropoffAddress}</Text>
          <Text style={styles.fareText}>Fare: KSh {ride.fareAmount}</Text>
        </View>

        {getActionButton()}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  card: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
  },
  status: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FF6B00',
    textAlign: 'center',
    marginBottom: 16,
  },
  rideInfo: {
    marginBottom: 16,
  },
  infoText: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  fareText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FF6B00',
    marginTop: 8,
  },
  actionButton: {
    backgroundColor: '#FF6B00',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  completeButton: {
    backgroundColor: '#4CAF50',
  },
  actionText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  markerPickup: {
    backgroundColor: '#FF6B00',
    padding: 8,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: 'white',
  },
  markerDropoff: {
    backgroundColor: '#4CAF50',
    padding: 8,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: 'white',
  },
  markerText: {
    color: 'white',
    fontWeight: 'bold',
  },
  driverMarker: {
    backgroundColor: 'white',
    padding: 4,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#FF6B00',
  },
});
