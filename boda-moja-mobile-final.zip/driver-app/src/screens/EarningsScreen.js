import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import api from '../services/api';

export default function EarningsScreen() {
  const [earnings, setEarnings] = useState(null);
  const [period, setPeriod] = useState('week');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    fetchEarnings();
  }, [period]);

  const fetchEarnings = async () => {
    setIsLoading(true);
    try {
      const response = await api.get('/drivers/me/earnings', {
        params: { period },
      });
      setEarnings(response.data.data);
    } catch (error) {
      console.error('Failed to fetch earnings:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const periods = [
    { key: 'week', label: 'This Week' },
    { key: 'month', label: 'This Month' },
    { key: 'all', label: 'All Time' },
  ];

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#FF6B00" />
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Earnings</Text>

      <View style={styles.periodSelector}>
        {periods.map((p) => (
          <TouchableOpacity
            key={p.key}
            style={[styles.periodButton, period === p.key && styles.periodButtonActive]}
            onPress={() => setPeriod(p.key)}
          >
            <Text style={[styles.periodText, period === p.key && styles.periodTextActive]}>
              {p.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {earnings && (
        <>
          <View style={styles.statsCard}>
            <View style={styles.stat}>
              <Text style={styles.statValue}>KSh {earnings.totalEarnings?.toLocaleString() || 0}</Text>
              <Text style={styles.statLabel}>Total Earnings</Text>
            </View>
            <View style={styles.stat}>
              <Text style={styles.statValue}>{earnings.completedRides || 0}</Text>
              <Text style={styles.statLabel}>Completed Rides</Text>
            </View>
            <View style={styles.stat}>
              <Text style={styles.statValue}>KSh {earnings.avgFare || 0}</Text>
              <Text style={styles.statLabel}>Average Fare</Text>
            </View>
          </View>

          <Text style={styles.sectionTitle}>Recent Rides</Text>
          {earnings.rides?.map((ride) => (
            <View key={ride.id} style={styles.rideCard}>
              <View style={styles.rideHeader}>
                <Text style={styles.rideDate}>
                  {new Date(ride.completedAt).toLocaleDateString('en-KE')}
                </Text>
                <Text style={styles.rideFare}>KSh {ride.fareAmount}</Text>
              </View>
              <Text style={styles.rideRoute} numberOfLines={2}>
                {ride.pickupAddress} → {ride.dropoffAddress}
              </Text>
              <Text style={styles.paymentStatus}>
                Payment: {ride.payment?.status || 'pending'}
              </Text>
            </View>
          ))}
        </>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    padding: 16,
    backgroundColor: 'white',
  },
  periodSelector: {
    flexDirection: 'row',
    padding: 16,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  periodButton: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginHorizontal: 4,
    backgroundColor: '#f0f0f0',
  },
  periodButtonActive: {
    backgroundColor: '#FF6B00',
  },
  periodText: {
    fontSize: 14,
    color: '#666',
  },
  periodTextActive: {
    color: 'white',
    fontWeight: 'bold',
  },
  statsCard: {
    flexDirection: 'row',
    backgroundColor: 'white',
    margin: 16,
    borderRadius: 16,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  stat: {
    flex: 1,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FF6B00',
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    paddingHorizontal: 16,
    marginTop: 16,
    marginBottom: 8,
  },
  rideCard: {
    backgroundColor: 'white',
    marginHorizontal: 16,
    marginBottom: 8,
    borderRadius: 12,
    padding: 16,
  },
  rideHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  rideDate: {
    fontSize: 12,
    color: '#999',
  },
  rideFare: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#FF6B00',
  },
  rideRoute: {
    fontSize: 14,
    color: '#333',
    marginBottom: 4,
  },
  paymentStatus: {
    fontSize: 12,
    color: '#999',
  },
});
