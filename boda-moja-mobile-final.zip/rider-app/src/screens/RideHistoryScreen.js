import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  RefreshControl,
} from 'react-native';
import api from '../services/api';

export default function RideHistoryScreen() {
  const [rides, setRides] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [page, setPage] = useState(1);

  useEffect(() => {
    fetchRides();
  }, []);

  const fetchRides = async (refresh = false) => {
    try {
      setIsLoading(true);
      const currentPage = refresh ? 1 : page;
      const response = await api.get('/rides/history', {
        params: { page: currentPage, limit: 10 },
      });

      const newRides = response.data.data.rides;
      setRides(refresh ? newRides : [...rides, ...newRides]);
      if (refresh) setPage(1);
    } catch (error) {
      console.error('Failed to fetch rides:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return '#4CAF50';
      case 'cancelled': return '#ff4444';
      case 'in_progress': return '#FF6B00';
      default: return '#999';
    }
  };

  const renderRide = ({ item }) => (
    <View style={styles.rideCard}>
      <View style={styles.rideHeader}>
        <Text style={styles.rideDate}>
          {new Date(item.requestedAt).toLocaleDateString('en-KE')}
        </Text>
        <View style={[styles.statusBadge, { backgroundColor: getStatusColor(item.status) }]}>
          <Text style={styles.statusText}>{item.status}</Text>
        </View>
      </View>

      <View style={styles.rideDetails}>
        <Text style={styles.address} numberOfLines={1}>
          📍 {item.pickupAddress || 'Unknown pickup'}
        </Text>
        <Text style={styles.address} numberOfLines={1}>
          🏁 {item.dropoffAddress || 'Unknown destination'}
        </Text>
      </View>

      <View style={styles.rideFooter}>
        <Text style={styles.fare}>KSh {item.fareAmount || 0}</Text>
        {item.driver && (
          <Text style={styles.driverName}>{item.driver.name}</Text>
        )}
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Ride History</Text>
      <FlatList
        data={rides}
        renderItem={renderRide}
        keyExtractor={(item) => item.id}
        refreshControl={
          <RefreshControl refreshing={isLoading} onRefresh={() => fetchRides(true)} />
        }
        onEndReached={() => fetchRides()}
        onEndReachedThreshold={0.5}
        contentContainerStyle={styles.listContent}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    padding: 16,
    backgroundColor: 'white',
  },
  listContent: {
    padding: 16,
  },
  rideCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  rideHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  rideDate: {
    fontSize: 12,
    color: '#999',
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  statusText: {
    color: 'white',
    fontSize: 10,
    fontWeight: 'bold',
    textTransform: 'uppercase',
  },
  rideDetails: {
    marginBottom: 12,
  },
  address: {
    fontSize: 14,
    color: '#333',
    marginBottom: 4,
  },
  rideFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
    paddingTop: 12,
  },
  fare: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FF6B00',
  },
  driverName: {
    fontSize: 14,
    color: '#666',
  },
});
