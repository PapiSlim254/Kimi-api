import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
} from 'react-native';
import MapView, { Marker, Polyline } from 'react-native-maps';
import MapViewDirections from 'react-native-maps-directions';
import { onEvent, offEvent, emitEvent } from '../services/socket';
import api from '../services/api';
import Toast from 'react-native-toast-message';

const { width, height } = Dimensions.get('window');

export default function RideScreen({ route, navigation }) {
  const { rideId, driver: initialDriver } = route.params;
  const [driver, setDriver] = useState(initialDriver);
  const [driverLocation, setDriverLocation] = useState(null);
  const [rideStatus, setRideStatus] = useState('accepted');
  const [eta, setEta] = useState(null);
  const mapRef = useRef(null);

  useEffect(() => {
    // Join ride room
    emitEvent('join_ride_room', { rideId });

    // Listen for events
    onEvent('driver_location', handleDriverLocation);
    onEvent('driver_arriving', handleDriverArriving);
    onEvent('ride_started', handleRideStarted);
    onEvent('ride_completed', handleRideCompleted);
    onEvent('ride_cancelled', handleRideCancelled);

    // Fetch ride details
    fetchRideDetails();

    return () => {
      offEvent('driver_location', handleDriverLocation);
      offEvent('driver_arriving', handleDriverArriving);
      offEvent('ride_started', handleRideStarted);
      offEvent('ride_completed', handleRideCompleted);
      offEvent('ride_cancelled', handleRideCancelled);
    };
  }, []);

  const fetchRideDetails = async () => {
    try {
      const response = await api.get(`/rides/${rideId}`);
      const ride = response.data.data.ride;
      setRideStatus(ride.status);
      if (ride.driver) setDriver(ride.driver);
    } catch (error) {
      console.error('Failed to fetch ride details:', error);
    }
  };

  const handleDriverLocation = (data) => {
    setDriverLocation({ lat: data.lat, lng: data.lng });
  };

  const handleDriverArriving = () => {
    setRideStatus('driver_arriving');
    Toast.show({ type: 'info', text1: 'Your driver has arrived!' });
  };

  const handleRideStarted = () => {
    setRideStatus('in_progress');
    Toast.show({ type: 'success', text1: 'Ride started!' });
  };

  const handleRideCompleted = (data) => {
    Toast.show({ type: 'success', text1: 'Ride completed!' });
    navigation.replace('Payment', { rideId, fare: data.fare });
  };

  const handleRideCancelled = (data) => {
    Toast.show({ type: 'error', text1: 'Ride cancelled', text2: data.reason });
    navigation.navigate('Main');
  };

  const handleCancel = async () => {
    try {
      await api.patch(`/rides/${rideId}/cancel`, { reason: 'Rider cancelled' });
      Toast.show({ type: 'info', text1: 'Ride cancelled' });
      navigation.navigate('Main');
    } catch (error) {
      Toast.show({ type: 'error', text1: 'Cannot cancel at this stage' });
    }
  };

  const getStatusText = () => {
    switch (rideStatus) {
      case 'accepted': return 'Driver is on the way';
      case 'driver_arriving': return 'Driver has arrived';
      case 'in_progress': return 'Heading to destination';
      default: return 'Loading...';
    }
  };

  return (
    <View style={styles.container}>
      <MapView
        ref={mapRef}
        style={styles.map}
        showsUserLocation
      >
        {driverLocation && (
          <Marker coordinate={{ latitude: driverLocation.lat, longitude: driverLocation.lng }}>
            <View style={styles.driverMarker}>
              <Text style={styles.driverEmoji}>🏍</Text>
            </View>
          </Marker>
        )}
      </MapView>

      <View style={styles.card}>
        <Text style={styles.status}>{getStatusText()}</Text>

        {driver && (
          <View style={styles.driverInfo}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>{driver.name?.[0] || '?'}</Text>
            </View>
            <View style={styles.driverDetails}>
              <Text style={styles.driverName}>{driver.name}</Text>
              <Text style={styles.driverRating}>⭐ {driver.ratingAvg || '5.0'}</Text>
            </View>
            <TouchableOpacity style={styles.callButton}>
              <Text style={styles.callButtonText}>📞</Text>
            </TouchableOpacity>
          </View>
        )}

        {rideStatus === 'accepted' && (
          <TouchableOpacity style={styles.cancelButton} onPress={handleCancel}>
            <Text style={styles.cancelButtonText}>Cancel Ride</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  card: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  status: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 16,
    color: '#FF6B00',
  },
  driverInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#FF6B00',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: {
    color: 'white',
    fontSize: 20,
    fontWeight: 'bold',
  },
  driverDetails: {
    flex: 1,
    marginLeft: 12,
  },
  driverName: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  driverRating: {
    fontSize: 14,
    color: '#666',
  },
  callButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
  },
  callButtonText: {
    fontSize: 20,
  },
  cancelButton: {
    backgroundColor: '#ff4444',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  cancelButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  driverMarker: {
    backgroundColor: 'white',
    padding: 6,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: '#FF6B00',
  },
  driverEmoji: {
    fontSize: 20,
  },
});
