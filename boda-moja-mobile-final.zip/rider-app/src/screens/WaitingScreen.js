import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import LottieView from 'lottie-react-native';
import { onEvent, offEvent } from '../services/socket';
import api from '../services/api';
import Toast from 'react-native-toast-message';

export default function WaitingScreen({ route, navigation }) {
  const { rideId, pickup, dropoff, fare } = route.params;
  const [elapsedTime, setElapsedTime] = useState(0);
  const [driver, setDriver] = useState(null);

  useEffect(() => {
    const timer = setInterval(() => {
      setElapsedTime(prev => prev + 1);
    }, 1000);

    onEvent('ride_accepted', handleRideAccepted);
    onEvent('no_drivers_found', handleNoDrivers);

    return () => {
      clearInterval(timer);
      offEvent('ride_accepted', handleRideAccepted);
      offEvent('no_drivers_found', handleNoDrivers);
    };
  }, []);

  const handleRideAccepted = (data) => {
    if (data.rideId === rideId) {
      setDriver(data.driver);
      Toast.show({ type: 'success', text1: 'Driver found!', text2: data.driver.name });
      setTimeout(() => {
        navigation.replace('Ride', { rideId, driver: data.driver });
      }, 1500);
    }
  };

  const handleNoDrivers = (data) => {
    if (data.rideId === rideId) {
      Toast.show({ type: 'error', text1: 'No drivers available' });
      navigation.goBack();
    }
  };

  const handleCancel = async () => {
    try {
      await api.patch(`/rides/${rideId}/cancel`, { reason: 'Rider cancelled' });
      Toast.show({ type: 'info', text1: 'Ride cancelled' });
      navigation.navigate('Main');
    } catch (error) {
      Toast.show({ type: 'error', text1: 'Failed to cancel ride' });
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <View style={styles.container}>
      <MapView
        style={styles.map}
        initialRegion={{
          latitude: pickup.lat,
          longitude: pickup.lng,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        }}
      >
        <Marker coordinate={{ latitude: pickup.lat, longitude: pickup.lng }}>
          <View style={styles.marker}>
            <Text style={styles.markerText}>P</Text>
          </View>
        </Marker>
      </MapView>

      <View style={styles.card}>
        <Text style={styles.title}>Finding your boda...</Text>

        <View style={styles.animationContainer}>
          <ActivityIndicator size="large" color="#FF6B00" />
        </View>

        <View style={styles.details}>
          <Text style={styles.detailText}>Pickup: {pickup.address}</Text>
          <Text style={styles.detailText}>Destination: {dropoff.address}</Text>
          <Text style={styles.fareText}>KSh {fare}</Text>
        </View>

        <Text style={styles.timer}>Waiting: {formatTime(elapsedTime)}</Text>

        <TouchableOpacity style={styles.cancelButton} onPress={handleCancel}>
          <Text style={styles.cancelButtonText}>Cancel Request</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  card: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
    alignItems: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  animationContainer: {
    height: 80,
    justifyContent: 'center',
    alignItems: 'center',
  },
  details: {
    width: '100%',
    marginVertical: 16,
  },
  detailText: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  fareText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FF6B00',
    marginTop: 8,
  },
  timer: {
    fontSize: 14,
    color: '#999',
    marginBottom: 16,
  },
  cancelButton: {
    backgroundColor: '#ff4444',
    padding: 16,
    borderRadius: 12,
    width: '100%',
    alignItems: 'center',
  },
  cancelButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  marker: {
    backgroundColor: '#FF6B00',
    padding: 8,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: 'white',
  },
  markerText: {
    color: 'white',
    fontWeight: 'bold',
  },
});
