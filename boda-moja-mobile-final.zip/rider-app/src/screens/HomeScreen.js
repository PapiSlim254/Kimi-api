import React, { useEffect, useState, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  Alert,
} from 'react-native';
import MapView, { Marker, Circle } from 'react-native-maps';
import { GooglePlacesAutocomplete } from 'react-native-google-places-autocomplete';
import { requestLocationPermission, getCurrentLocation, watchLocation } from '../services/location';
import api from '../services/api';
import useAuthStore from '../stores/authStore';
import { onEvent, offEvent, emitEvent } from '../services/socket';
import Toast from 'react-native-toast-message';

const { width, height } = Dimensions.get('window');
const ASPECT_RATIO = width / height;
const LATITUDE_DELTA = 0.0922;
const LONGITUDE_DELTA = LATITUDE_DELTA * ASPECT_RATIO;

export default function HomeScreen({ navigation }) {
  const { user } = useAuthStore();
  const mapRef = useRef(null);
  const [region, setRegion] = useState(null);
  const [pickup, setPickup] = useState(null);
  const [dropoff, setDropoff] = useState(null);
  const [nearbyDrivers, setNearbyDrivers] = useState([]);
  const [fare, setFare] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [hasActiveRide, setHasActiveRide] = useState(false);
  const [activeRideId, setActiveRideId] = useState(null);

  // Initialize location
  useEffect(() => {
    initializeLocation();
    checkActiveRide();

    // Listen for socket events
    onEvent('ride_accepted', handleRideAccepted);
    onEvent('driver_arriving', handleDriverArriving);
    onEvent('ride_started', handleRideStarted);
    onEvent('ride_completed', handleRideCompleted);
    onEvent('no_drivers_found', handleNoDrivers);
    onEvent('payment_confirmed', handlePaymentConfirmed);
    onEvent('payment_failed', handlePaymentFailed);

    return () => {
      offEvent('ride_accepted', handleRideAccepted);
      offEvent('driver_arriving', handleDriverArriving);
      offEvent('ride_started', handleRideStarted);
      offEvent('ride_completed', handleRideCompleted);
      offEvent('no_drivers_found', handleNoDrivers);
      offEvent('payment_confirmed', handlePaymentConfirmed);
      offEvent('payment_failed', handlePaymentFailed);
    };
  }, []);

  const initializeLocation = async () => {
    try {
      await requestLocationPermission();
      const location = await getCurrentLocation();

      setRegion({
        latitude: location.lat,
        longitude: location.lng,
        latitudeDelta: LATITUDE_DELTA,
        longitudeDelta: LONGITUDE_DELTA,
      });

      setPickup({
        lat: location.lat,
        lng: location.lng,
        address: 'Current Location',
      });

      fetchNearbyDrivers(location.lat, location.lng);
    } catch (error) {
      Toast.show({ type: 'error', text1: 'Location access required' });
    }
  };

  const fetchNearbyDrivers = async (lat, lng) => {
    try {
      const response = await api.get('/drivers/nearby', {
        params: { lat, lng, radius: 3000 },
      });
      setNearbyDrivers(response.data.data.drivers || []);
    } catch (error) {
      console.error('Failed to fetch nearby drivers:', error);
    }
  };

  const checkActiveRide = async () => {
    try {
      const response = await api.get('/rides/history', { params: { status: 'in_progress', limit: 1 } });
      const rides = response.data.data.rides;
      if (rides.length > 0) {
        setHasActiveRide(true);
        setActiveRideId(rides[0].id);
        navigation.navigate('Ride', { rideId: rides[0].id });
      }
    } catch (error) {
      console.error('Failed to check active ride:', error);
    }
  };

  const handlePlaceSelect = (data, details, type) => {
    const { lat, lng } = details.geometry.location;
    const address = data.description;

    if (type === 'pickup') {
      setPickup({ lat, lng, address });
      setRegion({
        latitude: lat,
        longitude: lng,
        latitudeDelta: LATITUDE_DELTA,
        longitudeDelta: LONGITUDE_DELTA,
      });
    } else {
      setDropoff({ lat, lng, address });
      calculateFare(pickup.lat, pickup.lng, lat, lng);
    }
  };

  const calculateFare = async (pickupLat, pickupLng, dropoffLat, dropoffLng) => {
    try {
      const response = await api.post('/rides/estimate', {
        pickupLat,
        pickupLng,
        dropoffLat,
        dropoffLng,
      });
      setFare(response.data.data);
    } catch (error) {
      console.error('Fare calculation failed:', error);
    }
  };

  const handleBookRide = async () => {
    if (!pickup || !dropoff) {
      Toast.show({ type: 'error', text1: 'Please select pickup and destination' });
      return;
    }

    setIsLoading(true);
    try {
      const response = await api.post('/rides', {
        pickupLat: pickup.lat,
        pickupLng: pickup.lng,
        pickupAddress: pickup.address,
        dropoffLat: dropoff.lat,
        dropoffLng: dropoff.lng,
        dropoffAddress: dropoff.address,
      });

      const { rideId, status } = response.data.data;

      if (status === 'no_drivers_found') {
        Toast.show({ type: 'error', text1: 'No drivers available nearby. Try again.' });
        setIsLoading(false);
        return;
      }

      setHasActiveRide(true);
      setActiveRideId(rideId);

      navigation.navigate('Waiting', { 
        rideId, 
        pickup, 
        dropoff, 
        fare: response.data.data.estimatedFare 
      });
    } catch (error) {
      Toast.show({ 
        type: 'error', 
        text1: error.response?.data?.error?.message || 'Failed to book ride' 
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Socket event handlers
  const handleRideAccepted = useCallback((data) => {
    if (data.rideId === activeRideId) {
      Toast.show({ type: 'success', text1: 'Driver found!', text2: `${data.driver.name} is on the way` });
      navigation.navigate('Ride', { rideId: data.rideId, driver: data.driver });
    }
  }, [activeRideId]);

  const handleDriverArriving = useCallback((data) => {
    if (data.rideId === activeRideId) {
      Toast.show({ type: 'info', text1: 'Driver has arrived!' });
    }
  }, [activeRideId]);

  const handleRideStarted = useCallback((data) => {
    if (data.rideId === activeRideId) {
      Toast.show({ type: 'info', text1: 'Ride started!' });
    }
  }, [activeRideId]);

  const handleRideCompleted = useCallback((data) => {
    if (data.rideId === activeRideId) {
      Toast.show({ type: 'success', text1: 'Ride completed!' });
      navigation.navigate('Payment', { rideId: data.rideId, fare: data.fare });
    }
  }, [activeRideId]);

  const handleNoDrivers = useCallback((data) => {
    if (data.rideId === activeRideId) {
      Toast.show({ type: 'error', text1: 'No drivers available. Please try again.' });
      setHasActiveRide(false);
      setActiveRideId(null);
    }
  }, [activeRideId]);

  const handlePaymentConfirmed = useCallback((data) => {
    if (data.rideId === activeRideId) {
      Toast.show({ type: 'success', text1: 'Payment confirmed!', text2: `Ref: ${data.mpesaRef}` });
      navigation.navigate('Rating', { rideId: data.rideId });
    }
  }, [activeRideId]);

  const handlePaymentFailed = useCallback((data) => {
    if (data.rideId === activeRideId) {
      Toast.show({ type: 'error', text1: 'Payment failed', text2: data.reason });
      Alert.alert(
        'Payment Failed',
        data.reason,
        [
          { text: 'Retry', onPress: () => navigation.navigate('Payment', { rideId: data.rideId }) },
          { text: 'OK', style: 'cancel' },
        ]
      );
    }
  }, [activeRideId]);

  if (!region) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#FF6B00" />
        <Text style={styles.loadingText}>Getting your location...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <MapView
        ref={mapRef}
        style={styles.map}
        region={region}
        showsUserLocation
        showsMyLocationButton
      >
        {pickup && (
          <Marker coordinate={{ latitude: pickup.lat, longitude: pickup.lng }}>
            <View style={styles.markerPickup}>
              <Text style={styles.markerText}>P</Text>
            </View>
          </Marker>
        )}

        {dropoff && (
          <Marker coordinate={{ latitude: dropoff.lat, longitude: dropoff.lng }}>
            <View style={styles.markerDropoff}>
              <Text style={styles.markerText}>D</Text>
            </View>
          </Marker>
        )}

        {nearbyDrivers.map((driver) => (
          <Marker
            key={driver.id}
            coordinate={{ latitude: driver.lat, longitude: driver.lng }}
          >
            <View style={styles.driverMarker}>
              <Text style={styles.driverMarkerText}>🏍</Text>
            </View>
          </Marker>
        ))}
      </MapView>

      <View style={styles.searchContainer}>
        <GooglePlacesAutocomplete
          placeholder="Where to?"
          onPress={(data, details = null) => handlePlaceSelect(data, details, 'dropoff')}
          query={{
            key: process.env.GOOGLE_PLACES_API_KEY,
            language: 'en',
            components: 'country:ke',
            location: `${region.latitude},${region.longitude}`,
            radius: 50000,
          }}
          fetchDetails
          styles={{
            container: styles.autocompleteContainer,
            textInput: styles.autocompleteInput,
            listView: styles.autocompleteList,
            row: styles.autocompleteRow,
          }}
          debounce={300}
          minLength={2}
          enablePoweredByContainer={false}
        />
      </View>

      {fare && (
        <View style={styles.fareCard}>
          <Text style={styles.fareTitle}>Ride Estimate</Text>
          <View style={styles.fareRow}>
            <Text style={styles.fareLabel}>Distance</Text>
            <Text style={styles.fareValue}>{fare.distanceKm} km</Text>
          </View>
          <View style={styles.fareRow}>
            <Text style={styles.fareLabel}>Estimated Time</Text>
            <Text style={styles.fareValue}>{fare.estimatedDuration} min</Text>
          </View>
          <View style={styles.fareRow}>
            <Text style={styles.fareLabelTotal}>Total Fare</Text>
            <Text style={styles.fareValueTotal}>KSh {fare.fare}</Text>
          </View>

          <TouchableOpacity 
            style={[styles.bookButton, isLoading && styles.bookButtonDisabled]}
            onPress={handleBookRide}
            disabled={isLoading}
          >
            {isLoading ? (
              <ActivityIndicator color="white" />
            ) : (
              <Text style={styles.bookButtonText}>Book Boda</Text>
            )}
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  map: {
    width: width,
    height: height,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FF6B00',
  },
  loadingText: {
    marginTop: 16,
    color: 'white',
    fontSize: 16,
  },
  searchContainer: {
    position: 'absolute',
    top: 50,
    left: 16,
    right: 16,
    zIndex: 1,
  },
  autocompleteContainer: {
    flex: 0,
  },
  autocompleteInput: {
    height: 50,
    borderRadius: 12,
    paddingHorizontal: 16,
    fontSize: 16,
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  autocompleteList: {
    backgroundColor: 'white',
    borderRadius: 12,
    marginTop: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  autocompleteRow: {
    padding: 12,
  },
  markerPickup: {
    backgroundColor: '#FF6B00',
    padding: 8,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: 'white',
  },
  markerDropoff: {
    backgroundColor: '#4CAF50',
    padding: 8,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: 'white',
  },
  markerText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 12,
  },
  driverMarker: {
    backgroundColor: 'white',
    padding: 4,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#FF6B00',
  },
  driverMarkerText: {
    fontSize: 16,
  },
  fareCard: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'white',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  fareTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#333',
  },
  fareRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  fareLabel: {
    fontSize: 14,
    color: '#666',
  },
  fareValue: {
    fontSize: 14,
    color: '#333',
    fontWeight: '500',
  },
  fareLabelTotal: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  fareValueTotal: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#FF6B00',
  },
  bookButton: {
    backgroundColor: '#FF6B00',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 16,
  },
  bookButtonDisabled: {
    opacity: 0.7,
  },
  bookButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
