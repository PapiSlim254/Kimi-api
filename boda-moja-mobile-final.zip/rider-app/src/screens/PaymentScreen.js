import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import api from '../services/api';
import { onEvent, offEvent } from '../services/socket';
import Toast from 'react-native-toast-message';

export default function PaymentScreen({ route, navigation }) {
  const { rideId, fare } = route.params;
  const [paymentStatus, setPaymentStatus] = useState('pending');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    onEvent('payment_confirmed', handlePaymentConfirmed);
    onEvent('payment_failed', handlePaymentFailed);

    return () => {
      offEvent('payment_confirmed', handlePaymentConfirmed);
      offEvent('payment_failed', handlePaymentFailed);
    };
  }, []);

  const handlePaymentConfirmed = (data) => {
    if (data.rideId === rideId) {
      setPaymentStatus('completed');
      Toast.show({ type: 'success', text1: 'Payment successful!', text2: `Ref: ${data.mpesaRef}` });
      setTimeout(() => {
        navigation.replace('Rating', { rideId });
      }, 2000);
    }
  };

  const handlePaymentFailed = (data) => {
    if (data.rideId === rideId) {
      setPaymentStatus('failed');
      Toast.show({ type: 'error', text1: 'Payment failed', text2: data.reason });
    }
  };

  const handleRetry = async () => {
    setIsLoading(true);
    try {
      await api.post(`/payments/${rideId}/retry`);
      setPaymentStatus('pending');
      Toast.show({ type: 'info', text1: 'Payment retry initiated' });
    } catch (error) {
      Toast.show({ type: 'error', text1: 'Retry failed' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCashPayment = () => {
    Toast.show({ type: 'info', text1: 'Please pay the driver directly' });
    navigation.replace('Rating', { rideId });
  };

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.title}>Payment</Text>

        <View style={styles.amountContainer}>
          <Text style={styles.amountLabel}>Total Amount</Text>
          <Text style={styles.amount}>KSh {fare}</Text>
        </View>

        {paymentStatus === 'pending' && (
          <View style={styles.statusContainer}>
            <ActivityIndicator size="large" color="#FF6B00" />
            <Text style={styles.statusText}>Waiting for M-Pesa confirmation...</Text>
            <Text style={styles.subText}>Check your phone for the STK push</Text>
          </View>
        )}

        {paymentStatus === 'completed' && (
          <View style={styles.statusContainer}>
            <Text style={styles.successIcon}>✅</Text>
            <Text style={styles.statusText}>Payment successful!</Text>
          </View>
        )}

        {paymentStatus === 'failed' && (
          <View style={styles.statusContainer}>
            <Text style={styles.errorIcon}>❌</Text>
            <Text style={styles.statusText}>Payment failed</Text>

            <TouchableOpacity 
              style={[styles.button, isLoading && styles.buttonDisabled]}
              onPress={handleRetry}
              disabled={isLoading}
            >
              {isLoading ? (
                <ActivityIndicator color="white" />
              ) : (
                <Text style={styles.buttonText}>Retry Payment</Text>
              )}
            </TouchableOpacity>

            <TouchableOpacity style={styles.cashButton} onPress={handleCashPayment}>
              <Text style={styles.cashButtonText}>Pay Driver Cash</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FF6B00',
    justifyContent: 'center',
    padding: 24,
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 24,
    padding: 32,
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 24,
  },
  amountContainer: {
    alignItems: 'center',
    marginBottom: 32,
  },
  amountLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
  },
  amount: {
    fontSize: 48,
    fontWeight: 'bold',
    color: '#FF6B00',
  },
  statusContainer: {
    alignItems: 'center',
    width: '100%',
  },
  statusText: {
    fontSize: 16,
    marginTop: 16,
    marginBottom: 8,
    textAlign: 'center',
  },
  subText: {
    fontSize: 12,
    color: '#999',
    marginBottom: 24,
  },
  successIcon: {
    fontSize: 64,
  },
  errorIcon: {
    fontSize: 64,
  },
  button: {
    backgroundColor: '#FF6B00',
    padding: 16,
    borderRadius: 12,
    width: '100%',
    alignItems: 'center',
    marginTop: 16,
  },
  buttonDisabled: {
    opacity: 0.7,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  cashButton: {
    backgroundColor: '#f0f0f0',
    padding: 16,
    borderRadius: 12,
    width: '100%',
    alignItems: 'center',
    marginTop: 12,
  },
  cashButtonText: {
    color: '#333',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
