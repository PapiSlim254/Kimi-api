import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import api from '../services/api';
import Toast from 'react-native-toast-message';

export default function RatingScreen({ route, navigation }) {
  const { rideId } = route.params;
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (rating === 0) {
      Toast.show({ type: 'error', text1: 'Please select a rating' });
      return;
    }

    setIsSubmitting(true);
    try {
      await api.post('/ratings', {
        rideId,
        score: rating,
        comment: comment.trim() || undefined,
      });

      Toast.show({ type: 'success', text1: 'Thank you for your feedback!' });
      navigation.navigate('Main');
    } catch (error) {
      Toast.show({ 
        type: 'error', 
        text1: error.response?.data?.error?.message || 'Failed to submit rating' 
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const renderStars = () => {
    return [1, 2, 3, 4, 5].map((star) => (
      <TouchableOpacity key={star} onPress={() => setRating(star)}>
        <Text style={[styles.star, star <= rating && styles.starSelected]}>
          {star <= rating ? '⭐' : '☆'}
        </Text>
      </TouchableOpacity>
    ));
  };

  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.title}>How was your ride?</Text>

        <View style={styles.starsContainer}>
          {renderStars()}
        </View>

        <TextInput
          style={styles.commentInput}
          placeholder="Any comments? (optional)"
          multiline
          numberOfLines={4}
          value={comment}
          onChangeText={setComment}
          maxLength={500}
        />

        <TouchableOpacity 
          style={[styles.button, isSubmitting && styles.buttonDisabled]}
          onPress={handleSubmit}
          disabled={isSubmitting}
        >
          <Text style={styles.buttonText}>Submit Rating</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => navigation.navigate('Main')}>
          <Text style={styles.skipText}>Skip</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FF6B00',
    justifyContent: 'center',
    padding: 24,
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 24,
    padding: 32,
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 24,
  },
  starsContainer: {
    flexDirection: 'row',
    marginBottom: 24,
  },
  star: {
    fontSize: 40,
    marginHorizontal: 4,
    color: '#ddd',
  },
  starSelected: {
    color: '#FFD700',
  },
  commentInput: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 12,
    padding: 12,
    width: '100%',
    height: 100,
    textAlignVertical: 'top',
    marginBottom: 24,
  },
  button: {
    backgroundColor: '#FF6B00',
    padding: 16,
    borderRadius: 12,
    width: '100%',
    alignItems: 'center',
  },
  buttonDisabled: {
    opacity: 0.7,
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  skipText: {
    color: '#999',
    marginTop: 16,
    fontSize: 14,
  },
});
