const { z } = require('zod');

// Phone number validation - Kenyan format
const phoneSchema = z.string()
  .min(10)
  .max(15)
  .transform((val) => {
    // Normalize to 254XXXXXXXXX format
    let cleaned = val.replace(/\s+/g, '').replace(/^\+/, '');
    if (cleaned.startsWith('0')) {
      cleaned = '254' + cleaned.slice(1);
    }
    return cleaned;
  })
  .refine((val) => /^2547[0-9]{8}$/.test(val), {
    message: 'Invalid Kenyan phone number format',
  });

// Auth validators
const riderRegisterSchema = z.object({
  phone: phoneSchema,
  name: z.string().min(2).max(100),
  password: z.string().min(6).max(100),
});

const driverRegisterSchema = z.object({
  phone: phoneSchema,
  name: z.string().min(2).max(100),
  password: z.string().min(6).max(100),
  idNumber: z.string().min(5).max(20),
  licenseNumber: z.string().min(5).max(20),
  saccoId: z.string().uuid().optional(),
});

const loginSchema = z.object({
  phone: phoneSchema,
  password: z.string().min(1),
});

// Ride validators
const createRideSchema = z.object({
  pickupLat: z.number().min(-90).max(90),
  pickupLng: z.number().min(-180).max(180),
  pickupAddress: z.string().min(3).max(300),
  dropoffLat: z.number().min(-90).max(90),
  dropoffLng: z.number().min(-180).max(180),
  dropoffAddress: z.string().min(3).max(300),
});

const rideActionSchema = z.object({
  rideId: z.string().uuid(),
});

const cancelRideSchema = z.object({
  reason: z.string().min(1).max(500).optional(),
});

// Driver status update
const driverStatusSchema = z.object({
  isOnline: z.boolean(),
});

// Location update
const locationUpdateSchema = z.object({
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
});

// Rating
const createRatingSchema = z.object({
  rideId: z.string().uuid(),
  score: z.number().int().min(1).max(5),
  comment: z.string().max(500).optional(),
});

// Nearby drivers query
const nearbyDriversSchema = z.object({
  lat: z.coerce.number().min(-90).max(90),
  lng: z.coerce.number().min(-180).max(180),
  radius: z.coerce.number().min(100).max(10000).default(3000),
});

module.exports = {
  riderRegisterSchema,
  driverRegisterSchema,
  loginSchema,
  createRideSchema,
  rideActionSchema,
  cancelRideSchema,
  driverStatusSchema,
  locationUpdateSchema,
  createRatingSchema,
  nearbyDriversSchema,
};
