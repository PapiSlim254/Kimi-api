const prisma = require('../lib/prisma');
const redis = require('../lib/redis');
const { success, error } = require('../lib/response');
const AppError = require('../lib/AppError');
const logger = require('../lib/logger');

// Validate coordinate inputs
const validateCoordinates = (lat, lng) => {
  const numLat = Number(lat);
  const numLng = Number(lng);

  if (isNaN(numLat) || isNaN(numLng)) {
    throw new AppError('INVALID_COORDINATES', 'Latitude and longitude must be valid numbers', 400);
  }

  if (numLat < -90 || numLat > 90 || numLng < -180 || numLng > 180) {
    throw new AppError('INVALID_COORDINATES', 'Coordinates out of valid range', 400);
  }

  return { lat: numLat, lng: numLng };
};

// Find nearest online drivers within radius (in meters)
const findNearestDrivers = async (lat, lng, radius = 3000, limit = 5) => {
  try {
    // Validate inputs FIRST
    const coords = validateCoordinates(lat, lng);
    const numRadius = Math.min(Math.max(Number(radius), 100), 10000); // Clamp 100m-10km
    const numLimit = Math.min(Math.max(Number(limit), 1), 20); // Clamp 1-20

    // First try Redis for live positions (fastest)
    const driverKeys = await redis.keys('driver:*:location');
    const liveDrivers = [];

    for (const key of driverKeys) {
      const driverId = key.split(':')[1];
      const locData = await redis.get(key);

      if (locData) {
        const { lat: dLat, lng: dLng, timestamp } = JSON.parse(locData);

        // Check if location is fresh (within last 60 seconds)
        if (Date.now() - timestamp < 60000) {
          const distance = calculateDistance(coords.lat, coords.lng, dLat, dLng);
          if (distance <= numRadius) {
            liveDrivers.push({ driverId, distance, lat: dLat, lng: dLng });
          }
        }
      }
    }

    // Sort by distance
    liveDrivers.sort((a, b) => a.distance - b.distance);

    // Get driver details from database
    const driverIds = liveDrivers.slice(0, numLimit).map(d => d.driverId);

    if (driverIds.length === 0) {
      // Fallback to PostgreSQL if no Redis data
      return await findNearestFromDB(coords.lat, coords.lng, numRadius, numLimit);
    }

    const drivers = await prisma.driver.findMany({
      where: {
        id: { in: driverIds },
        isOnline: true,
        isVerified: true,
        isActive: true,
      },
      select: {
        id: true,
        name: true,
        phone: true,
        ratingAvg: true,
        sacco: { select: { name: true } },
      },
    });

    // Merge distance data with driver details
    const result = liveDrivers
      .slice(0, numLimit)
      .map(ld => {
        const driver = drivers.find(d => d.id === ld.driverId);
        if (!driver) return null;
        return {
          ...driver,
          distance: Math.round(ld.distance),
          lat: ld.lat,
          lng: ld.lng,
        };
      })
      .filter(Boolean);

    return result;
  } catch (err) {
    if (err.isOperational) throw err;
    logger.error('Error finding nearest drivers', { error: err.message, lat, lng });
    return [];
  }
};

// Fallback: Find nearest drivers from PostgreSQL
const findNearestFromDB = async (lat, lng, radius, limit) => {
  try {
    // All inputs are already validated numbers at this point
    // Using Prisma's safe parameterized query
    const drivers = await prisma.$queryRaw`
      SELECT 
        d.id,
        d.name,
        d.phone,
        d.rating_avg as "ratingAvg",
        dl.lat,
        dl.lng,
        SQRT(POWER(69.1 * (dl.lat - ${lat}), 2) + POWER(69.1 * (${lng} - dl.lng) * COS(dl.lat / 57.3), 2)) * 1609.34 as distance
      FROM drivers d
      JOIN driver_locations dl ON d.id = dl.driver_id
      WHERE d.is_online = true 
        AND d.is_verified = true 
        AND d.is_active = true
        AND SQRT(POWER(69.1 * (dl.lat - ${lat}), 2) + POWER(69.1 * (${lng} - dl.lng) * COS(dl.lat / 57.3), 2)) * 1609.34 <= ${radius}
      ORDER BY distance ASC
      LIMIT ${limit}
    `;

    return drivers.map(d => ({
      ...d,
      distance: Math.round(d.distance),
      lat: parseFloat(d.lat),
      lng: parseFloat(d.lng),
    }));
  } catch (err) {
    logger.error('DB fallback failed', { error: err.message, lat, lng });
    return [];
  }
};

// Calculate distance between two coordinates using Haversine formula (in meters)
const calculateDistance = (lat1, lng1, lat2, lng2) => {
  const R = 6371000; // Earth's radius in meters
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;

  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
};

// Calculate fare based on distance
const calculateFare = (distanceKm) => {
  const BASE_FARE = 50;      // KES
  const PER_KM_RATE = 30;    // KES per km
  const MINIMUM_FARE = 80;   // KES

  const calculated = BASE_FARE + (distanceKm * PER_KM_RATE);
  return Math.max(Math.round(calculated), MINIMUM_FARE);
};

// Estimate distance and fare between two points
const estimateRide = (pickupLat, pickupLng, dropoffLat, dropoffLng) => {
  const coords1 = validateCoordinates(pickupLat, pickupLng);
  const coords2 = validateCoordinates(dropoffLat, dropoffLng);

  const distanceKm = calculateDistance(coords1.lat, coords1.lng, coords2.lat, coords2.lng) / 1000;
  const fare = calculateFare(distanceKm);

  return {
    distanceKm: Math.round(distanceKm * 100) / 100,
    fare,
    estimatedDuration: Math.round(distanceKm * 3), // ~3 min per km in Nairobi traffic
  };
};

module.exports = {
  findNearestDrivers,
  findNearestFromDB,
  calculateDistance,
  calculateFare,
  estimateRide,
  validateCoordinates,
};
