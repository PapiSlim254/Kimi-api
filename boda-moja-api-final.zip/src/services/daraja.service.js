const axios = require('axios');
const crypto = require('crypto');
const logger = require('../lib/logger');

const BASE_URL = process.env.NODE_ENV === 'production'
  ? 'https://api.safaricom.co.ke'
  : 'https://sandbox.safaricom.co.ke';

// Token cache
let cachedToken = null;
let tokenExpiry = null;

const getAccessToken = async () => {
  if (cachedToken && tokenExpiry && Date.now() < tokenExpiry - 60000) {
    return cachedToken;
  }

  try {
    const credentials = Buffer.from(
      `${process.env.DARAJA_CONSUMER_KEY}:${process.env.DARAJA_CONSUMER_SECRET}`
    ).toString('base64');

    const { data } = await axios.get(
      `${BASE_URL}/oauth/v1/generate?grant_type=client_credentials`,
      { headers: { Authorization: `Basic ${credentials}` } }
    );

    cachedToken = data.access_token;
    tokenExpiry = Date.now() + (data.expires_in * 1000);
    logger.info('Daraja access token refreshed');

    return cachedToken;
  } catch (err) {
    logger.error('Failed to get Daraja access token', { error: err.message });
    throw err;
  }
};

const getTimestamp = () => {
  return new Date().toISOString().replace(/[-T:.Z]/g, '').slice(0, 14);
};

const generatePassword = (timestamp) => {
  const raw = `${process.env.DARAJA_SHORTCODE}${process.env.DARAJA_PASSKEY}${timestamp}`;
  return Buffer.from(raw).toString('base64');
};

const formatPhone = (phone) => {
  let cleaned = phone.replace(/\s+/g, '').replace(/^\+/, '');
  if (cleaned.startsWith('0')) {
    cleaned = '254' + cleaned.slice(1);
  }
  return cleaned;
};

// STK Push - charge a rider
const initiateSTKPush = async ({ phone, amount, rideId }) => {
  const token = await getAccessToken();
  const timestamp = getTimestamp();
  const password = generatePassword(timestamp);

  const payload = {
    BusinessShortCode: process.env.DARAJA_SHORTCODE,
    Password: password,
    Timestamp: timestamp,
    TransactionType: 'CustomerPayBillOnline',
    Amount: Math.round(amount),
    PartyA: formatPhone(phone),
    PartyB: process.env.DARAJA_SHORTCODE,
    PhoneNumber: formatPhone(phone),
    CallBackURL: process.env.DARAJA_CALLBACK_URL,
    AccountReference: `BodaMoja-${rideId.slice(0, 8)}`,
    TransactionDesc: 'Ride payment',
  };

  logger.info('Initiating STK Push', { 
    phone: formatPhone(phone), 
    amount, 
    rideId: rideId.slice(0, 8) 
  });

  const { data } = await axios.post(
    `${BASE_URL}/mpesa/stkpush/v1/processrequest`,
    payload,
    { headers: { Authorization: `Bearer ${token}` } }
  );

  if (data.ResponseCode !== '0') {
    throw new Error(`STK Push failed: ${data.ResponseDescription}`);
  }

  logger.info('STK Push initiated successfully', { 
    checkoutRequestId: data.CheckoutRequestID 
  });

  return {
    merchantRequestId: data.MerchantRequestID,
    checkoutRequestId: data.CheckoutRequestID,
    responseCode: data.ResponseCode,
    responseDescription: data.ResponseDescription,
  };
};

// Query STK status
const querySTKStatus = async (checkoutRequestId) => {
  const token = await getAccessToken();
  const timestamp = getTimestamp();
  const password = generatePassword(timestamp);

  const { data } = await axios.post(
    `${BASE_URL}/mpesa/stkpushquery/v1/query`,
    {
      BusinessShortCode: process.env.DARAJA_SHORTCODE,
      Password: password,
      Timestamp: timestamp,
      CheckoutRequestID: checkoutRequestId,
    },
    { headers: { Authorization: `Bearer ${token}` } }
  );

  return data;
};

// B2C payout to driver
const payDriver = async ({ driverPhone, amount, reference }) => {
  const token = await getAccessToken();

  const payload = {
    InitiatorName: process.env.DARAJA_INITIATOR_NAME,
    SecurityCredential: process.env.DARAJA_SECURITY_CREDENTIAL,
    CommandID: 'BusinessPayment',
    Amount: Math.round(amount),
    PartyA: process.env.DARAJA_B2C_SHORTCODE,
    PartyB: formatPhone(driverPhone),
    Remarks: `Boda Moja - ${reference}`,
    QueueTimeOutURL: `${process.env.BASE_URL}/payments/b2c/timeout`,
    ResultURL: `${process.env.BASE_URL}/payments/b2c/callback`,
    Occasion: 'DriverPayout',
  };

  logger.info('Initiating B2C payout', { 
    phone: formatPhone(driverPhone), 
    amount, 
    reference 
  });

  const { data } = await axios.post(
    `${BASE_URL}/mpesa/b2c/v3/paymentrequest`,
    payload,
    { headers: { Authorization: `Bearer ${token}` } }
  );

  return data;
};

module.exports = {
  initiateSTKPush,
  querySTKStatus,
  payDriver,
  formatPhone,
};
