const jwt = require('jsonwebtoken');
const redis = require('../lib/redis');
const prisma = require('../lib/prisma');
const logger = require('../lib/logger');

let io = null;

// Connection rate limiting
const connectionCounts = new Map();
const MAX_CONNECTIONS_PER_IP = 10;
const PAYLOAD_SIZE_LIMIT = 10000; // 10KB

// Cleanup connection counts periodically
setInterval(() => {
  connectionCounts.clear();
}, 60 * 60 * 1000); // Clear every hour

const initSocket = (socketIo) => {
  io = socketIo;

  // Authentication middleware
  io.use(async (socket, next) => {
    try {
      // Rate limit connections per IP
      const clientIp = socket.handshake.headers['x-forwarded-for']?.split(',')[0]?.trim() ||
                       socket.handshake.address;

      const currentCount = connectionCounts.get(clientIp) || 0;
      if (currentCount >= MAX_CONNECTIONS_PER_IP) {
        logger.warn('Socket connection rate limit exceeded', { ip: clientIp, count: currentCount });
        return next(new Error('Too many connections from this IP'));
      }

      connectionCounts.set(clientIp, currentCount + 1);
      socket.clientIp = clientIp;

      // Attach cleanup on disconnect
      socket.on('disconnect', () => {
        const count = connectionCounts.get(clientIp) || 1;
        if (count <= 1) {
          connectionCounts.delete(clientIp);
        } else {
          connectionCounts.set(clientIp, count - 1);
        }
      });

      // JWT validation
      const token = socket.handshake.auth?.token;

      if (!token) {
        return next(new Error('Authentication required'));
      }

      const decoded = jwt.verify(token, process.env.JWT_SECRET, {
        issuer: 'bodamoja.com',
        audience: 'bodamoja-app',
      });

      let user;
      if (decoded.role === 'rider') {
        user = await prisma.user.findUnique({ 
          where: { id: decoded.id },
          select: { id: true, phone: true, name: true, isActive: true }
        });
      } else if (decoded.role === 'driver') {
        user = await prisma.driver.findUnique({ 
          where: { id: decoded.id },
          select: { id: true, phone: true, name: true, isActive: true, isVerified: true }
        });
      }

      if (!user || !user.isActive) {
        return next(new Error('User not found or inactive'));
      }

      socket.user = { ...user, role: decoded.role };
      next();
    } catch (err) {
      logger.warn('Socket authentication failed', { error: err.message, ip: socket.handshake.address });
      next(new Error('Invalid token'));
    }
  });

  // Payload size limit middleware
  io.use((socket, next) => {
    const originalOn = socket.on;
    socket.on = function(event, handler) {
      return originalOn.call(this, event, (...args) => {
        const payloadSize = JSON.stringify(args).length;
        if (payloadSize > PAYLOAD_SIZE_LIMIT) {
          logger.warn('Socket payload too large', { 
            event, 
            size: payloadSize, 
            userId: socket.user?.id,
            maxAllowed: PAYLOAD_SIZE_LIMIT 
          });
          return;
        }
        return handler.apply(this, args);
      });
    };
    next();
  });

  io.on('connection', (socket) => {
    const { id, role, name } = socket.user;
    logger.info(`${role} connected`, { userId: id, socketId: socket.id, name, ip: socket.clientIp });

    // Join personal room
    socket.join(`user:${id}`);

    // Driver-specific events
    if (role === 'driver') {
      socket.on('location_update', async (data) => {
        await handleLocationUpdate(socket, data);
      });

      socket.on('go_online', async () => {
        await handleGoOnline(socket);
      });

      socket.on('go_offline', async () => {
        await handleGoOffline(socket);
      });

      socket.on('join_ride_room', ({ rideId }) => {
        socket.join(`ride:${rideId}`);
        logger.info('Driver joined ride room', { driverId: id, rideId });
      });
    }

    // Rider-specific events
    if (role === 'rider') {
      socket.on('join_ride_room', ({ rideId }) => {
        socket.join(`ride:${rideId}`);
        logger.info('Rider joined ride room', { riderId: id, rideId });
      });
    }

    // Disconnect handler
    socket.on('disconnect', async (reason) => {
      logger.info(`${role} disconnected`, { 
        userId: id, 
        socketId: socket.id, 
        reason,
        ip: socket.clientIp
      });

      if (role === 'driver') {
        await handleDriverDisconnect(socket);
      }
    });
  });
};

// Handle driver location update
const handleLocationUpdate = async (socket, { lat, lng }) => {
  const driverId = socket.user.id;
  const timestamp = Date.now();

  try {
    // Validate coordinates
    const numLat = Number(lat);
    const numLng = Number(lng);

    if (isNaN(numLat) || isNaN(numLng) || 
        numLat < -90 || numLat > 90 || 
        numLng < -180 || numLng > 180) {
      logger.warn('Invalid coordinates from driver', { driverId, lat, lng });
      return;
    }

    // Update Redis (fast, ephemeral)
    await redis.setex(
      `driver:${driverId}:location`,
      30,
      JSON.stringify({ lat: numLat, lng: numLng, timestamp })
    );

    // Update PostgreSQL (persistent)
    await prisma.driverLocation.upsert({
      where: { driverId },
      update: { 
        lat: numLat.toString(), 
        lng: numLng.toString(), 
        updatedAt: new Date() 
      },
      create: { 
        driverId, 
        lat: numLat.toString(), 
        lng: numLng.toString() 
      },
    });

    // If driver is on an active ride, push to rider
    const activeRide = await prisma.ride.findFirst({
      where: {
        driverId,
        status: { in: ['accepted', 'driver_arriving', 'in_progress'] },
      },
      select: { id: true, riderId: true },
    });

    if (activeRide) {
      io.to(`ride:${activeRide.id}`).emit('driver_location', { lat: numLat, lng: numLng });
    }
  } catch (err) {
    logger.error('Location update failed', { driverId, error: err.message });
  }
};

// Handle driver going online
const handleGoOnline = async (socket) => {
  const driverId = socket.user.id;

  try {
    await prisma.driver.update({
      where: { id: driverId },
      data: { isOnline: true },
    });

    socket.user.isOnline = true;
    logger.info('Driver went online', { driverId });
  } catch (err) {
    logger.error('Failed to set driver online', { driverId, error: err.message });
  }
};

// Handle driver going offline
const handleGoOffline = async (socket) => {
  const driverId = socket.user.id;

  try {
    await prisma.driver.update({
      where: { id: driverId },
      data: { isOnline: false },
    });

    // Remove from Redis
    await redis.del(`driver:${driverId}:location`);

    socket.user.isOnline = false;
    logger.info('Driver went offline', { driverId });
  } catch (err) {
    logger.error('Failed to set driver offline', { driverId, error: err.message });
  }
};

// Handle driver disconnect with grace period
const handleDriverDisconnect = async (socket) => {
  const driverId = socket.user.id;

  // Wait 15 seconds before marking offline
  setTimeout(async () => {
    try {
      // Check if driver reconnected
      const sockets = await io.in(`user:${driverId}`).fetchSockets();
      if (sockets.length > 0) return;

      // Check if location key still exists
      const exists = await redis.exists(`driver:${driverId}:location`);
      if (exists) return;

      // Mark offline
      await prisma.driver.update({
        where: { id: driverId },
        data: { isOnline: false },
      });

      logger.info('Driver marked offline after disconnect', { driverId });
    } catch (err) {
      logger.error('Failed to mark driver offline', { driverId, error: err.message });
    }
  }, 15000);
};

// Emit to specific user
const emitToUser = (userId, event, data) => {
  if (!io) {
    logger.warn('Socket.io not initialized, cannot emit');
    return;
  }
  io.to(`user:${userId}`).emit(event, data);
};

// Emit to ride room
const emitToRide = (rideId, event, data) => {
  if (!io) {
    logger.warn('Socket.io not initialized, cannot emit');
    return;
  }
  io.to(`ride:${rideId}`).emit(event, data);
};

module.exports = { initSocket, emitToUser, emitToRide };
